// 使用 jQuery 确保在 DOM 加载完毕后执行我们的代码
jQuery(() => {
    // -----------------------------------------------------------------
    // 1. 定义常量和状态变量
    // -----------------------------------------------------------------
    const extensionName = "preset-manager-momo";
    const extensionFolderPath = `scripts/extensions/third-party/${extensionName}`;

    // Helper function for delays
    const delay = (ms) => new Promise((res) => setTimeout(res, ms));

    // HTML-safe escape function
    const escapeHtml = (unsafe) => {
        if (unsafe === null || typeof unsafe === "undefined") return "";
        // A more robust way to escape HTML to avoid issues with string literals
        const replacements = {
            "&": "&",
            "<": "<",
            ">": ">",
            '"': "&quot;",
            "'": "&#039;",
        };
        return String(unsafe).replace(
            /[&<>"']/g,
            (match) => replacements[match]
        );
    };

    // 存储键 (仅用于UI状态)
    const STORAGE_KEY_BUTTON_POS = "momo-preset-manager-button-position";
    const STORAGE_KEY_ENABLED = "momo-preset-manager-enabled";

    // DOM IDs and Selectors
    const BUTTON_ID = "momo-preset-manager-button";
    const OVERLAY_ID = "momo-preset-manager-popup-overlay";
    const POPUP_ID = "momo-preset-manager-popup";
    const CLOSE_BUTTON_ID = "momo-preset-manager-popup-close-button";
    const TOGGLE_ID = "#momo-preset-manager-enabled-toggle";

    // DOM 元素引用
    let mainView,
        modifyView,
        batchDeleteView,
        transferView,
        presetListContainer,
        overlay;
    // -- "编辑预设"区域
    let editPresetSelect, editActionsContainer;
    let gotoModifyBtn, gotoBatchDeleteBtn, gotoTransferBtn;
    // -- "修改条目"子页面
    let momoModifyPresetSelect,
        momoSettingSelect,
        momoUserPrompt,
        momoAiResponse,
        momoSubmitModificationBtn,
        momoSaveManualChangesBtn,
        momoPromptEditorContainer,
        momoPromptName,
        momoPromptContent,
        momoPromptEnabled,
        momoPromptSystemPrompt,
        momoPromptMarker,
        momoPromptForbidOverrides,
        momoPromptRole,
        momoPromptInjectionPosition,
        momoPromptInjectionDepth,
        momoPromptIdentifier;
    // -- "批量管理"子页面
    let batchDeletePresetListContainer,
        batchDeleteEntryListContainer,
        batchDeletePresetsBtn,
        batchDeleteEntriesBtn;
    // -- "条目复制"子页面
    let momoSourcePresetSelect,
        momoTargetPresetSelect,
        momoSourceEntriesContainer,
        momoTransferEntriesBtn;

    // API 实例
    let stApi; // SillyTavern Preset Manager
    let tavernHelperApi; // For AI generation features

    // -----------------------------------------------------------------
    // 2. SillyTavern API 封装 (重构)
    // -----------------------------------------------------------------

    /**
     * 直接、即时地获取当前可用的 Preset Manager API 实例。
     * 此函数假定在用户交互（如点击按钮）时，API 应该已经准备就绪。
     * 如果 API 未就绪，它将立即抛出明确的错误，而不是等待或轮询。
     * @returns {Promise<object>} Preset Manager 实例
     * @throws {Error} 如果任何获取步骤失败
     */
    async function getPresetManagerNow(retries = 5, interval = 500) {
        const context = window["SillyTavern"]?.getContext();
        if (!context || typeof context.getPresetManager !== "function") {
            throw new Error(
                "SillyTavern API (getContext or getPresetManager) is not available."
            );
        }

        for (let i = 0; i < retries; i++) {
            try {
                let presetManager = await context.getPresetManager();

                // Fallback for 'custom' API to use 'openai' manager
                if (!presetManager) {
                    const currentApi =
                        context.chatCompletionSettings
                            ?.chat_completion_source ||
                        context.textCompletionSettings?.completion_source;
                    if (currentApi === "custom") {
                        console.warn(
                            `[${extensionName}] PresetManager for 'custom' API not found. Attempting to use 'openai' manager as a fallback.`
                        );
                        presetManager = await context.getPresetManager(
                            "openai"
                        );
                    }
                }

                if (
                    presetManager &&
                    typeof presetManager.getAllPresets === "function"
                ) {
                    console.log(
                        `[${extensionName}] Successfully obtained PresetManager for API: ${
                            presetManager.apiId
                        } on attempt ${i + 1}.`
                    );
                    return presetManager;
                }

                console.warn(
                    `[${extensionName}] Attempt ${
                        i + 1
                    }: PresetManager not ready. Retrying in ${interval}ms...`
                );
                await new Promise((resolve) => setTimeout(resolve, interval));
            } catch (error) {
                console.error(
                    `[${extensionName}] Error during attempt ${
                        i + 1
                    } to get PresetManager:`,
                    error
                );
                await new Promise((resolve) => setTimeout(resolve, interval));
            }
        }

        const apiId =
            context.chatCompletionSettings?.chat_completion_source ||
            context.textCompletionSettings?.completion_source;
        throw new Error(
            `Failed to get a valid Preset Manager for API "${
                apiId || "Unknown"
            }" after ${retries} attempts. The API may not support presets or might not be fully initialized.`
        );
    }

    /**
     * 轮询等待 tavern-helper API 可用
     * @returns {Promise<object>}
     */
    async function waitForTavernHelper(retries = 10, interval = 300) {
        for (let i = 0; i < retries; i++) {
            if (
                window["TavernHelper"] &&
                typeof window["TavernHelper"].generateRaw === "function"
            ) {
                console.log(`[${extensionName}] TavernHelper is available.`);
                return window["TavernHelper"];
            }
            await delay(interval);
        }
        toastr.error("TavernHelper not found. AI features will not work.");
        throw new Error("TavernHelper not found.");
    }

    // -----------------------------------------------------------------
    // 3. 弹窗和视图管理
    // -----------------------------------------------------------------
    function showPopup() {
        if (overlay) overlay.css("display", "flex");
        showMainView();
    }

    function closePopup() {
        if (overlay) overlay.hide();
    }

    async function showMainView() {
        mainView.show();
        modifyView.hide();
        batchDeleteView.hide();
        transferView.hide();
        await renderPresets();
        await populateEditPresetSelect();
    }

    async function showSubView(viewId) {
        mainView.hide();
        [modifyView, batchDeleteView, transferView].forEach((v) =>
            v ? v.hide() : null
        );

        if (viewId === "momo-modify-view") {
            await populateModifyPresetSelect();
            const selectedPreset = editPresetSelect.val();
            if (selectedPreset) {
                momoModifyPresetSelect.val(selectedPreset).trigger("change");
            }
        }
        if (viewId === "momo-batch-delete-view") {
            await renderBatchDeleteView();
        }
        if (viewId === "momo-transfer-view") {
            await populateTransferView();
        }
        $(`#${viewId}`).show();
    }

    // -----------------------------------------------------------------
    // 4. 浮动按钮管理 (代码不变)
    // -----------------------------------------------------------------
    function makeButtonDraggable($button) {
        let isDragging = false,
            offset = { x: 0, y: 0 },
            wasDragged = false;
        function dragStart(e) {
            isDragging = true;
            wasDragged = false;
            $button.css("cursor", "grabbing");
            const touch = e.touches ? e.touches[0] : e;
            const buttonPos = $button.offset();
            offset = {
                x: touch.clientX - buttonPos.left,
                y: touch.clientY - buttonPos.top,
            };
        }
        function dragMove(e) {
            if (!isDragging) return;
            wasDragged = true;
            e.preventDefault();
            const touch = e.touches ? e.touches[0] : e;
            $button.css({
                top: `${touch.clientY - offset.y}px`,
                left: `${touch.clientX - offset.x}px`,
                right: "auto",
                bottom: "auto",
            });
        }
        function dragEnd() {
            if (!isDragging) return;
            isDragging = false;
            $button.css("cursor", "grab");
            localStorage.setItem(
                STORAGE_KEY_BUTTON_POS,
                JSON.stringify({
                    top: $button.css("top"),
                    left: $button.css("left"),
                })
            );
        }
        $button.on("mousedown touchstart", dragStart);
        $(document).on("mousemove touchmove", dragMove);
        $(document).on("mouseup touchend", dragEnd);
        $button.on("click", function (e) {
            if (wasDragged) {
                e.preventDefault();
            } else {
                showPopup();
            }
        });
    }
    function handleWindowResize($button) {
        let resizeTimeout;
        $(window).on("resize.momo-preset-manager", () => {
            clearTimeout(resizeTimeout);
            resizeTimeout = setTimeout(() => {
                if (!$button.length) return;
                const maxLeft = $(window).width() - $button.outerWidth(),
                    maxTop = $(window).height() - $button.outerHeight();
                let { left, top } = $button.offset();
                if (left > maxLeft) $button.css("left", `${maxLeft}px`);
                if (left < 0) $button.css("left", "0px");
                if (top > maxTop) $button.css("top", `${maxTop}px`);
                if (top < 0) $button.css("top", "0px");
                localStorage.setItem(
                    STORAGE_KEY_BUTTON_POS,
                    JSON.stringify({
                        top: $button.css("top"),
                        left: $button.css("left"),
                    })
                );
            }, 150);
        });
    }
    function initializeFloatingButton() {
        if ($(`#${BUTTON_ID}`).length) return;
        $("body").append(
            `<div id="${BUTTON_ID}" title="预设管理器"><i class="fa-solid fa-sliders"></i></div>`
        );
        const $button = $(`#${BUTTON_ID}`);
        const savedPos = JSON.parse(
            localStorage.getItem(STORAGE_KEY_BUTTON_POS)
        );
        $button.css(
            savedPos
                ? { top: savedPos.top, left: savedPos.left }
                : { top: "150px", right: "20px" }
        );
        makeButtonDraggable($button);
        handleWindowResize($button);
    }
    function destroyFloatingButton() {
        $(`#${BUTTON_ID}`).remove();
        $(window).off("resize.momo-preset-manager");
    }

    // -----------------------------------------------------------------
    // 4.5 更新器模块 (代码不变)
    // -----------------------------------------------------------------
    const Updater = {
        gitRepoOwner: "1830488003",
        gitRepoName: "preset-manager-momo",
        currentVersion: "1.2.0",
        latestVersion: "1.2.0",
        changelogContent: "",
        async fetchRawFileFromGitHub(filePath) {
            const url = `https://raw.githubusercontent.com/${this.gitRepoOwner}/${this.gitRepoName}/main/${filePath}`;
            const response = await fetch(url, { cache: "no-cache" });
            if (!response.ok) {
                throw new Error(
                    `Failed to fetch ${filePath} from GitHub: ${response.statusText}`
                );
            }
            return response.text();
        },
        parseVersion(content) {
            try {
                return JSON.parse(content).version || "0.0.0";
            } catch (error) {
                console.error("Failed to parse version:", error);
                return "0.0.0";
            }
        },
        compareVersions(v1, v2) {
            const parts1 = v1.split(".").map(Number);
            const parts2 = v2.split(".").map(Number);
            for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
                const p1 = parts1[i] || 0;
                const p2 = parts2[i] || 0;
                if (p1 > p2) return 1;
                if (p1 < p2) return -1;
            }
            return 0;
        },
        async performUpdate() {
            const context = window["SillyTavern"].getContext();
            const { getRequestHeaders } = context.common;
            const { extension_types } = context.extensions;
            toastr.info("正在开始更新...");
            try {
                const response = await fetch("/api/extensions/update", {
                    method: "POST",
                    headers: getRequestHeaders(),
                    body: JSON.stringify({
                        extensionName: extensionName,
                        global: extension_types[extensionName] === "global",
                    }),
                });
                if (!response.ok) throw new Error(await response.text());
                toastr.success("更新成功！将在3秒后刷新页面应用更改。");
                setTimeout(() => location.reload(), 3000);
            } catch (error) {
                toastr.error(`更新失败: ${error.message}`);
            }
        },
        async showUpdateConfirmDialog() {
            const context = window["SillyTavern"].getContext();
            const { POPUP_TYPE, callGenericPopup } = context.popup;
            try {
                this.changelogContent = await this.fetchRawFileFromGitHub(
                    "CHANGELOG.md"
                );
            } catch (error) {
                this.changelogContent = `发现新版本 ${this.latestVersion}！您想现在更新吗？`;
            }
            if (
                await callGenericPopup(
                    this.changelogContent,
                    POPUP_TYPE.CONFIRM,
                    {
                        okButton: "立即更新",
                        cancelButton: "稍后",
                        wide: true,
                        large: true,
                    }
                )
            ) {
                await this.performUpdate();
            }
        },
        async checkForUpdates(isManual = false) {
            const updateButton = $("#momo-check-update-button");
            if (isManual) {
                updateButton
                    .prop("disabled", true)
                    .html('<i class="fas fa-spinner fa-spin"></i> 检查中...');
            }
            try {
                const localManifestText = await (
                    await fetch(
                        `/${extensionFolderPath}/manifest.json?t=${Date.now()}`
                    )
                ).text();
                this.currentVersion = this.parseVersion(localManifestText);
                $("#momo-current-version").text(this.currentVersion);
                const remoteManifestText = await this.fetchRawFileFromGitHub(
                    "manifest.json"
                );
                this.latestVersion = this.parseVersion(remoteManifestText);
                if (
                    this.compareVersions(
                        this.latestVersion,
                        this.currentVersion
                    ) > 0
                ) {
                    updateButton
                        .html(
                            `<i class="fa-solid fa-gift"></i> 发现新版 ${this.latestVersion}!`
                        )
                        .off("click")
                        .on("click", () => this.showUpdateConfirmDialog());
                    if (isManual)
                        toastr.success(
                            `发现新版本 ${this.latestVersion}！点击按钮进行更新。`
                        );
                } else {
                    if (isManual) toastr.info("您当前已是最新版本。");
                }
            } catch (error) {
                if (isManual) toastr.error(`检查更新失败: ${error.message}`);
            } finally {
                if (
                    isManual &&
                    this.compareVersions(
                        this.latestVersion,
                        this.currentVersion
                    ) <= 0
                ) {
                    updateButton
                        .prop("disabled", false)
                        .html(
                            '<i class="fa-solid fa-cloud-arrow-down"></i> 检查更新'
                        );
                }
            }
        },
    };

    // -----------------------------------------------------------------
    // 5. 预设核心逻辑 (重写)
    // -----------------------------------------------------------------

    /**
     * [重写] 获取所有预设并将其作为普通对象返回。
     * 采用最直接可靠的方式，调用SillyTavern的内部函数 getPresetList()。
     */
    async function getPresets() {
        try {
            const stApi = await getPresetManagerNow();
            const { presets, preset_names } = stApi.getPresetList();

            if (!presets || !preset_names) {
                console.error(`[${extensionName}] getPresetList() 返回了无效数据。`);
                return {};
            }

            const presetsData = {};
            if (stApi.isKeyedApi()) {
                (preset_names || []).forEach((name, index) => {
                    if (name && presets[index]) presetsData[name] = presets[index];
                });
            } else {
                for (const name in (preset_names || {})) {
                    const index = preset_names[name];
                    if (name && presets[index]) presetsData[name] = presets[index];
                }
            }
            return presetsData;
        } catch (error) {
            console.error(`[${extensionName}] getPresets 失败:`, error);
            return {};
        }
    }

    async function renderPresets() {
        try {
            const stApi = await getPresetManagerNow();
            const presets = await getPresets();
            const presetNames = Object.keys(presets);
            presetListContainer.empty();

            if (presetNames.length === 0) {
                presetListContainer.append(
                    '<p class="momo-no-tasks">没有找到预设。请先在SillyTavern的生成设置面板中保存一个预设。</p>'
                );
                return;
            }

            // 正确且健壮的方案：通过API获取当前选中的预设名称
            const currentDisplayName = stApi.getSelectedPresetName();

            // 遍历并渲染每个预设
            presetNames.forEach((presetName) => {
                const item = $(
                    `<div class="momo-preset-item" title="点击加载预设"><span>${escapeHtml(
                        presetName
                    )}</span><div><button class="momo-delete-preset-btn" title="删除预设">&times;</button></div></div>`
                );

                // 如果是当前预设，则添加高亮类
                if (presetName === currentDisplayName) {
                    item.addClass("momo-preset-item-active");
                }

                // 绑定点击加载事件
                item.on("click", async (e) => {
                    if (!$(e.target).hasClass("momo-delete-preset-btn")) {
                        await applyPreset(presetName);
                    }
                });

                // 绑定删除事件
                item.find(".momo-delete-preset-btn").on("click", (e) => {
                    e.stopPropagation();
                    if (confirm(`确定删除预设 "${escapeHtml(presetName)}"?`)) {
                        deletePreset(presetName);
                    }
                });
                presetListContainer.append(item);
            });
        } catch (error) {
            console.error(
                `[${extensionName}] Failed to render presets:`,
                error
            );
            toastr.error(`加载预设列表失败: ${error.message}`);
            presetListContainer
                .empty()
                .append(
                    '<p class="momo-no-tasks" style="color:var(--danger-color);">加载预设列表时出错，请检查浏览器控制台获取详细信息。</p>'
                );
        }
    }


    /**
     * 应用（加载）指定的预设。
     * @param {string} presetName - 要加载的预设名称。
     */
    async function applyPreset(presetName) {
        try {
            const stApi = await getPresetManagerNow();
            const presetValue = stApi.findPreset(presetName);
            if (presetValue !== undefined && presetValue !== null) {
                // 应用预设，这将更新主UI的 #presets 下拉菜单
                stApi.selectPreset(presetValue);
                toastr.success(`预设 "${presetName}" 已成功加载！`);
                // 重新渲染我们的列表，它将从更新后的主UI中读取正确的状态
                await renderPresets();
            } else {
                throw new Error(`Preset named "${presetName}" could not be found.`);
            }
        } catch (error) {
            console.error(`[${extensionName}] Error applying preset:`, error);
            toastr.error(`应用预设失败: ${error.message}`);
        }
    }

    /**
     * 删除指定的预设。
     * @param {string} presetName - 要删除的预设名称。
     */
    async function deletePreset(presetName) {
        try {
            const stApi = await getPresetManagerNow();
            await stApi.deletePreset(presetName);
            toastr.success(`预设 "${presetName}" 已删除。`);
            await showMainView(); // 重新渲染主视图
        } catch (error) {
            console.error(`[${extensionName}] Error deleting preset:`, error);
            toastr.error(`删除预设失败: ${error.message}`);
        }
    }

    /**
     * 更新高级功能按钮的可用状态。
     */
    async function populateEditPresetSelect() {
        const presets = await getPresets();
        const presetNames = Object.keys(presets);
        const placeholder =
            '<option value="">--选择一个预设进行编辑--</option>';
        editPresetSelect.empty().append(placeholder);
        presetNames.forEach((name) =>
            editPresetSelect.append(
                `<option value="${escapeHtml(name)}">${escapeHtml(
                    name
                )}</option>`
            )
        );
        editPresetSelect.trigger("change");
    }

    async function populateModifyPresetSelect() {
        const presets = await getPresets();
        const presetNames = Object.keys(presets);
        const placeholder = '<option value="">--请选择一个预设--</option>';
        momoModifyPresetSelect.empty().append(placeholder);
        presetNames.forEach((name) =>
            momoModifyPresetSelect.append(
                `<option value="${escapeHtml(name)}">${escapeHtml(
                    name
                )}</option>`
            )
        );
    }

    async function populatePresetSettingSelect() {
        const presetName = momoModifyPresetSelect.val();
        momoSettingSelect
            .empty()
            .append('<option value="">--选择一个设置项--</option>');
        // 隐藏编辑器
        momoPromptEditorContainer.hide();

        if (!presetName) {
            momoSettingSelect.prop("disabled", true);
            return;
        }

        const presets = await getPresets();
        const settings = presets[presetName];

        if (settings) {
            momoSettingSelect
                .prop("disabled", false)
                .data("settings", settings);

            // 只加载 prompts 数组中的项目
            if (Array.isArray(settings.prompts)) {
                settings.prompts.forEach((prompt, index) => {
                    // 使用 "prompt:索引" 的格式作为唯一值，以便后续查找
                    const optionValue = `prompt:${index}`;
                    // 使用 prompt 的 name 属性作为显示文本
                    const optionText = prompt.name || `Prompt ${index + 1}`; // 提供一个备用名称
                    momoSettingSelect.append(
                        `<option value="${escapeHtml(
                            optionValue
                        )}">${escapeHtml(optionText)}</option>`
                    );
                });
            }
        } else {
            momoSettingSelect.prop("disabled", true);
        }
        momoSettingSelect.trigger("change");
    }

    function handleSettingSelectionChange() {
        const selectedValue = momoSettingSelect.val();
        const settings = momoSettingSelect.data("settings") || {};

        if (!selectedValue || !selectedValue.startsWith("prompt:")) {
            momoPromptEditorContainer.hide();
            return;
        }

        const index = parseInt(selectedValue.split(":")[1], 10);
        if (Array.isArray(settings.prompts) && settings.prompts[index]) {
            const promptData = settings.prompts[index];

            // 填充表单
            momoPromptName.val(promptData.name || "");
            momoPromptContent.val(promptData.content || "");
            momoPromptEnabled.prop("checked", !!promptData.enabled);
            momoPromptSystemPrompt.prop("checked", !!promptData.system_prompt);
            momoPromptMarker.prop("checked", !!promptData.marker);
            momoPromptForbidOverrides.prop(
                "checked",
                !!promptData.forbid_overrides
            );
            momoPromptRole.val(promptData.role || "system");
            momoPromptInjectionPosition.val(promptData.injection_position ?? 0);
            momoPromptInjectionDepth.val(promptData.injection_depth ?? 0);
            momoPromptIdentifier.val(promptData.identifier || "");

            // 显示编辑器
            momoPromptEditorContainer.show();
        } else {
            momoPromptEditorContainer.hide();
        }
    }

    /**
     * 手动保存对预设中某个条目的修改。
     */
    async function handleManualSave() {
        const presetName = momoModifyPresetSelect.val();
        const selectedValue = momoSettingSelect.val();

        if (
            !presetName ||
            !selectedValue ||
            !selectedValue.startsWith("prompt:")
        ) {
            toastr.warning("请先选择一个预设和一个有效的提示项。");
            return;
        }

        try {
            const stApi = await getPresetManagerNow();
            const presets = await getPresets();
            const settings = presets[presetName];

            if (!settings) {
                throw new Error("找不到要更新的预设。");
            }

            const index = parseInt(selectedValue.split(":")[1], 10);
            if (!Array.isArray(settings.prompts) || !settings.prompts[index]) {
                throw new Error("找不到要更新的提示项索引。");
            }

            // 从表单收集数据，构建新的 prompt 对象
            const updatedPrompt = {
                identifier: momoPromptIdentifier.val(), // ID 通常不应更改，但我们还是读取它
                system_prompt: momoPromptSystemPrompt.is(":checked"),
                enabled: momoPromptEnabled.is(":checked"),
                marker: momoPromptMarker.is(":checked"),
                name: momoPromptName.val(),
                role: momoPromptRole.val(),
                content: momoPromptContent.val(),
                injection_position: parseInt(
                    momoPromptInjectionPosition.val(),
                    10
                ),
                injection_depth: parseInt(momoPromptInjectionDepth.val(), 10),
                forbid_overrides: momoPromptForbidOverrides.is(":checked"),
            };

            const displayKey = updatedPrompt.name || `Prompt ${index + 1}`;
            settings.prompts[index] = updatedPrompt; // 替换整个对象

            await stApi.savePreset(presetName, settings);

            toastr.success(
                `预设 "${presetName}" 的设置项 "${displayKey}" 已成功保存！`
            );
            // 更新UI中缓存的设置数据以反映更改
            momoSettingSelect.data("settings", settings);
        } catch (error) {
            console.error(
                `[${extensionName}] Error during manual save:`,
                error
            );
            toastr.error(`手动保存失败: ${error.message}.`);
        }
    }

    /**
     * 提交用户指令，让 AI 修改预设值。
     */
    async function handleSubmitModification() {
        const presetName = momoModifyPresetSelect.val();
        const selectedValue = momoSettingSelect.val();
        const userPromptText = momoUserPrompt.val().trim();

        if (!presetName || !selectedValue || !userPromptText) {
            toastr.warning("请选择预设、设置项并输入修改要求。");
            return;
        }

        momoAiResponse.val("正在请求AI，请稍候...");
        momoSubmitModificationBtn.prop("disabled", true);

        try {
            if (!tavernHelperApi) {
                tavernHelperApi = await waitForTavernHelper();
            }
            const stApi = await getPresetManagerNow();
            const presets = await getPresets();
            const presetSettings = presets[presetName];

            if (!presetSettings) {
                throw new Error("找不到指定的预设。");
            }

            let currentValue;
            let displayKey = "";

            if (selectedValue.startsWith("prompt:")) {
                const index = parseInt(selectedValue.split(":")[1], 10);
                if (
                    Array.isArray(presetSettings.prompts) &&
                    presetSettings.prompts[index]
                ) {
                    currentValue = presetSettings.prompts[index];
                    displayKey = currentValue.name;
                } else {
                    throw new Error("找不到要修改的提示项。");
                }
            } else {
                throw new Error("无效的设置项。");
            }

            const currentValueJson = JSON.stringify(currentValue, null, 2);
            const finalPrompt = `你是一个精准的JSON对象修改助手。\n**任务:** 根据用户的要求，修改下方提供的JSON对象。\n**核心规则:**\n1. 你的回复**必须**只包含修改后的、完整的JSON对象。\n2. 这个对象必须是有效的JSON格式。\n3. **绝对禁止**任何解释、注释、对话或代码块（\`\`\`json ... \`\`\`）。你的输出就是纯粹的、完整的JSON对象。\n\n---\n**当前设置项:** \`${displayKey}\`\n**当前JSON对象:**\n${currentValueJson}\n\n**用户的要求:**\n"${userPromptText}"\n\n**你的输出 (只有新的、完整的JSON对象):**`;

            const rawAiResponse = await tavernHelperApi.generateRaw({
                ordered_prompts: [{ role: "user", content: finalPrompt }],
                max_new_tokens: 1024,
                temperature: 0.1,
            });
            momoAiResponse.val(rawAiResponse);

            let newValue;
            try {
                newValue = JSON.parse(rawAiResponse.trim());
            } catch (e) {
                throw new Error(
                    `AI返回的不是有效的JSON值。请检查AI的回复并重试。`
                );
            }

            // 更新并保存
            if (selectedValue.startsWith("prompt:")) {
                const index = parseInt(selectedValue.split(":")[1], 10);
                presetSettings.prompts[index] = newValue;
            }

            await stApi.savePreset(presetName, presetSettings);

            toastr.success(`AI已成功修改设置项 "${displayKey}"！`);
            // 更新UI缓存并刷新显示
            momoSettingSelect.data("settings", presetSettings);
            handleSettingSelectionChange();
        } catch (error) {
            console.error(
                `[${extensionName}] Error during AI modification:`,
                error
            );
            toastr.error(`操作失败: ${error.message}`);
            momoAiResponse.val(`错误: ${error.message}`);
        } finally {
            momoSubmitModificationBtn.prop("disabled", false);
        }
    }

    // -----------------------------------------------------------------
    // 5.5 批量删除功能
    // -----------------------------------------------------------------
    /**
     * 渲染批量删除视图。
     * 此函数获取所有可用的预设，并将它们作为可选择的按钮渲染到批量删除界面上。
     * 用户可以点击这些按钮来选择一个或多个预设进行后续操作。
     */
    async function renderBatchDeleteView() {
        try {
            const presets = await getPresets();
            const presetNames = Object.keys(presets);
            batchDeletePresetListContainer.empty();

            if (presetNames.length === 0) {
                batchDeletePresetListContainer.append(
                    '<p class="momo-no-tasks">没有找到预设。</p>'
                );
                return;
            }

            presetNames.forEach((presetName) => {
                const presetButton = $("<button></button>")
                    .addClass("momo-book-button") // Reusing style from world book
                    .text(escapeHtml(presetName))
                    .attr("data-preset-name", presetName)
                    .on("click", function () {
                        $(this).toggleClass("selected");
                        loadEntriesForBatchDelete();
                    });
                batchDeletePresetListContainer.append(presetButton);
            });
        } catch (error) {
            console.error(
                `[${extensionName}] Failed to render batch delete view:`,
                error
            );
            toastr.error("加载预设列表失败。");
        }
        // Initially load entries (which will be an empty state)
        loadEntriesForBatchDelete();
    }

    /**
     * 为批量删除加载条目。
     * 当用户在批量删除视图中选择一个或多个预设后，此函数会被调用。
     * 它会获取所选预设中的所有条目（prompts），并将它们作为可选择的按钮显示出来。
     */
    async function loadEntriesForBatchDelete() {
        batchDeleteEntryListContainer.empty();
        const selectedPresetButtons = batchDeletePresetListContainer.find(
            ".momo-book-button.selected"
        );

        if (selectedPresetButtons.length === 0) {
            batchDeleteEntryListContainer.html(
                '<p class="momo-no-tasks">请先在上方选择一个或多个预设。</p>'
            );
            return;
        }

        try {
            const allPresets = await getPresets();
            for (const button of selectedPresetButtons) {
                const presetName = $(button).data("preset-name");
                const presetData = allPresets[presetName];

                if (presetData && Array.isArray(presetData.prompts)) {
                    presetData.prompts.forEach((prompt, index) => {
                        const entryName = prompt.name || `Prompt ${index + 1}`;
                        const entryButton = $("<button></button>")
                            .addClass("momo-book-button")
                            .text(escapeHtml(entryName))
                            .attr(
                                "title",
                                `属于: ${presetName}\n${prompt.content.substring(
                                    0,
                                    100
                                )}...`
                            )
                            .attr("data-preset-name", presetName)
                            .attr("data-prompt-index", index)
                            .on("click", function () {
                                $(this).toggleClass("selected");
                            });
                        batchDeleteEntryListContainer.append(entryButton);
                    });
                }
            }

            if (batchDeleteEntryListContainer.children("button").length === 0) {
                batchDeleteEntryListContainer.html(
                    '<p class="momo-no-tasks">选中的预设中没有条目。</p>'
                );
            }
        } catch (error) {
            console.error(
                `[${extensionName}] Failed to load entries for batch delete:`,
                error
            );
            toastr.error("加载条目列表失败。");
        }
    }

    /**
     * 处理批量删除预设的逻辑。
     * 此函数会获取所有被选中的预设，并向用户确认删除操作。
     * 确认后，它会逐一调用 `deletePreset` 函数来删除这些预设，并在完成后刷新视图。
     */
    async function handleBatchDeletePresets() {
        const selectedPresetButtons = batchDeletePresetListContainer.find(
            ".momo-book-button.selected"
        );
        if (selectedPresetButtons.length === 0) {
            toastr.warning("请先选择要删除的预设。");
            return;
        }

        const presetNamesToDelete = selectedPresetButtons
            .map((_, btn) => $(btn).data("preset-name"))
            .get();

        if (
            confirm(
                `确定要永久删除选中的 ${presetNamesToDelete.length} 个预设吗？此操作不可撤销！`
            )
        ) {
            try {
                const stApi = await getPresetManagerNow();
                for (const presetName of presetNamesToDelete) {
                    await stApi.deletePreset(presetName);
                }
                toastr.success("选中的预设已成功删除。");
                await renderBatchDeleteView(); // Re-render the whole view
            } catch (error) {
                console.error(`[${extensionName}] 批量删除预设失败:`, error);
                toastr.error("批量删除预设失败。");
            }
        }
    }

    /**
     * 处理批量删除条目的逻辑。
     * 此函数会收集所有被选中的条目，并按其所属的预设进行分组。
     * 在用户确认后，它会遍历每个受影响的预设，从中删除选定的条目，
     * 然后保存更改。为了防止因索引变化导致的错误，删除操作会从后往前进行。
     */
    async function handleBatchDeleteEntries() {
        const selectedEntryButtons = batchDeleteEntryListContainer.find(
            ".momo-book-button.selected"
        );
        if (selectedEntryButtons.length === 0) {
            toastr.warning("请先选择要删除的条目。");
            return;
        }

        const entriesToDeleteByPreset = {};
        selectedEntryButtons.each((_, block) => {
            const presetName = $(block).data("preset-name");
            const promptIndex = parseInt($(block).data("prompt-index"), 10);
            if (!entriesToDeleteByPreset[presetName]) {
                entriesToDeleteByPreset[presetName] = [];
            }
            entriesToDeleteByPreset[presetName].push(promptIndex);
        });

        if (
            confirm(
                `确定要永久删除选中的 ${selectedEntryButtons.length} 个条目吗？此操作不可撤销！`
            )
        ) {
            try {
                const stApi = await getPresetManagerNow();
                const allPresets = await getPresets();

                for (const presetName in entriesToDeleteByPreset) {
                    const presetData = allPresets[presetName];
                    const indicesToDelete = entriesToDeleteByPreset[
                        presetName
                    ].sort((a, b) => b - a); // Sort descending to avoid index shifting issues

                    if (presetData && Array.isArray(presetData.prompts)) {
                        for (const index of indicesToDelete) {
                            presetData.prompts.splice(index, 1);
                        }
                        await stApi.savePreset(presetName, presetData);
                    }
                }
                toastr.success("选中的条目已成功删除。");
                await loadEntriesForBatchDelete(); // Just reload the entries
            } catch (error) {
                console.error(`[${extensionName}] 批量删除条目失败:`, error);
                toastr.error("批量删除条目失败。");
            }
        }
    }

    // -----------------------------------------------------------------
    // 5.6 条目复制功能
    // -----------------------------------------------------------------
    /**
     * 填充条目复制视图。
     * 此函数获取所有预设，并用它们填充“源预设”和“目标预设”的下拉选择框。
     */
    async function populateTransferView() {
        momoSourceEntriesContainer.html(
            '<p class="momo-no-tasks">请先选择一个源预设。</p>'
        ); // Reset
        try {
            const presets = await getPresets();
            const presetNames = Object.keys(presets);
            const placeholder = '<option value="">--请选择预设--</option>';
            momoSourcePresetSelect.empty().append(placeholder);
            momoTargetPresetSelect.empty().append(placeholder);

            presetNames.forEach((name) => {
                const option = `<option value="${escapeHtml(
                    name
                )}">${escapeHtml(name)}</option>`;
                momoSourcePresetSelect.append(option);
                momoTargetPresetSelect.append(option);
            });
        } catch (error) {
            console.error(
                `[${extensionName}] 填充复制视图下拉菜单失败:`,
                error
            );
            toastr.error("加载预设列表失败。");
        }
    }

    /**
     * 渲染源预设的条目。
     * 当用户在条目复制视图中选择了一个“源预设”后，此函数被调用。
     * 它会获取该预设的所有条目，并以带复选框的形式渲染出来，供用户选择。
     */
    async function renderSourceEntries() {
        const sourcePresetName = momoSourcePresetSelect.val();
        if (!sourcePresetName) {
            momoSourceEntriesContainer.html(
                '<p class="momo-no-tasks">请先选择一个源预设。</p>'
            );
            return;
        }

        momoSourceEntriesContainer.html("<p>加载中...</p>");
        try {
            const allPresets = await getPresets();
            const sourcePresetData = allPresets[sourcePresetName];

            // Cache the entries data on the container
            momoSourceEntriesContainer.data(
                "entries",
                sourcePresetData?.prompts || []
            );

            momoSourceEntriesContainer.empty();
            if (
                !sourcePresetData ||
                !Array.isArray(sourcePresetData.prompts) ||
                sourcePresetData.prompts.length === 0
            ) {
                momoSourceEntriesContainer.html(
                    '<p class="momo-no-tasks">该预设没有条目。</p>'
                );
                return;
            }

            // Use checkboxes for selection
            sourcePresetData.prompts.forEach((prompt, index) => {
                const entryId = `momo-transfer-entry-${index}`;
                const displayName = prompt.name || `Prompt ${index + 1}`;
                const entryElement = $(`
                    <div class="momo-checkbox-item">
                        <input type="checkbox" id="${entryId}" value="${index}">
                        <label for="${entryId}">${escapeHtml(
                    displayName
                )}</label>
                    </div>
                `);
                momoSourceEntriesContainer.append(entryElement);
            });
        } catch (error) {
            console.error(`[${extensionName}] 加载源条目失败:`, error);
            toastr.error("加载源预设的条目失败。");
            momoSourceEntriesContainer.html(
                '<p style="color:red;">加载条目失败！</p>'
            );
        }
    }

    /**
     * 处理执行条目复制的逻辑。
     * 当用户在条目复制视图中点击“执行复制”按钮时，此函数被调用。
     * 它会验证用户的选择，然后获取选中的条目，将它们深拷贝后添加到目标预设中，
     * 最后保存对目标预设的更改。
     */
    async function handleTransferEntries() {
        const sourcePresetName = momoSourcePresetSelect.val();
        const targetPresetName = momoTargetPresetSelect.val();
        const selectedEntryIndices = momoSourceEntriesContainer
            .find('input[type="checkbox"]:checked')
            .map((_, el) => parseInt($(el).val(), 10))
            .get();

        // 1. Validation
        if (!sourcePresetName || !targetPresetName) {
            toastr.warning("请选择源预设和目标预设。");
            return;
        }
        if (sourcePresetName === targetPresetName) {
            toastr.warning("源预设和目标预设不能是同一个。");
            return;
        }
        if (selectedEntryIndices.length === 0) {
            toastr.warning("请至少选择一个要复制的条目。");
            return;
        }

        momoTransferEntriesBtn.prop("disabled", true).text("复制中...");

        try {
            const stApi = await getPresetManagerNow();
            const allPresets = await getPresets();
            const sourceEntries =
                momoSourceEntriesContainer.data("entries") || [];
            const targetPresetData = allPresets[targetPresetName];

            if (!targetPresetData) {
                throw new Error(`找不到目标预设 "${targetPresetName}"。`);
            }
            if (!Array.isArray(targetPresetData.prompts)) {
                targetPresetData.prompts = []; // Initialize if it doesn't exist
            }

            // 2. Filter and clone entries to transfer
            const entriesToTransfer = selectedEntryIndices.map((index) => {
                // Deep clone to prevent any object reference issues
                return JSON.parse(JSON.stringify(sourceEntries[index]));
            });

            // 3. Append to target and save
            targetPresetData.prompts.push(...entriesToTransfer);
            await stApi.savePreset(targetPresetName, targetPresetData);

            toastr.success(
                `成功将 ${entriesToTransfer.length} 个条目从 "${sourcePresetName}" 复制到 "${targetPresetName}"！`
            );

            // 4. Clear selection after transfer
            momoSourceEntriesContainer
                .find('input[type="checkbox"]:checked')
                .prop("checked", false);
        } catch (error) {
            console.error(`[${extensionName}] 复制条目失败:`, error);
            toastr.error(`复制失败: ${error.message}`);
        } finally {
            momoTransferEntriesBtn.prop("disabled", false).text("执行复制");
        }
    }

    // -----------------------------------------------------------------
    // 6. 初始化流程
    // -----------------------------------------------------------------
    async function initializeExtension() {
        $("head").append(
            `<link rel="stylesheet" type="text/css" href="${extensionFolderPath}/style.css">`
        );
        try {
            const [settingsHtml, popupHtml] = await Promise.all([
                $.get(`${extensionFolderPath}/settings.html`),
                $.get(`${extensionFolderPath}/popup.html`),
            ]);
            $("#extensions_settings2").append(settingsHtml);
            $("body").append(popupHtml);
        } catch (error) {
            console.error(
                `[${extensionName}] Failed to load HTML files.`,
                error
            );
            return;
        }

        mainView = $("#momo-main-view");
        modifyView = $("#momo-modify-view");
        batchDeleteView = $("#momo-batch-delete-view");
        transferView = $("#momo-transfer-view");
        presetListContainer = $("#momo-preset-list-container");
        overlay = $(`#${OVERLAY_ID}`);
        editPresetSelect = $("#momo-edit-preset-select");
        editActionsContainer = $("#momo-edit-actions-container");
        gotoModifyBtn = $("#momo-goto-modify-btn");
        gotoBatchDeleteBtn = $("#momo-goto-batch-delete-btn");
        gotoTransferBtn = $("#momo-goto-transfer-btn");
        momoModifyPresetSelect = $("#momo-modify-preset-select");
        momoSettingSelect = $("#momo-setting-select");
        momoUserPrompt = $("#momo-user-prompt");
        momoAiResponse = $("#momo-ai-response");
        momoSubmitModificationBtn = $("#momo-submit-modification-btn");
        momoSaveManualChangesBtn = $("#momo-save-manual-changes-btn");

        // 新的编辑器UI元素
        momoPromptEditorContainer = $("#momo-prompt-editor-container");
        momoPromptName = $("#momo-prompt-name");
        momoPromptContent = $("#momo-prompt-content");
        momoPromptEnabled = $("#momo-prompt-enabled");
        momoPromptSystemPrompt = $("#momo-prompt-system_prompt");
        momoPromptMarker = $("#momo-prompt-marker");
        momoPromptForbidOverrides = $("#momo-prompt-forbid_overrides");
        momoPromptRole = $("#momo-prompt-role");
        momoPromptInjectionPosition = $("#momo-prompt-injection_position");
        momoPromptInjectionDepth = $("#momo-prompt-injection_depth");
        momoPromptIdentifier = $("#momo-prompt-identifier");

        // Batch delete view
        batchDeletePresetListContainer = $(
            "#batch-delete-preset-list-container"
        );
        batchDeleteEntryListContainer = $("#batch-delete-entry-list-container");
        batchDeletePresetsBtn = $("#batch-delete-presets-btn");
        batchDeleteEntriesBtn = $("#batch-delete-entries-btn");

        // Transfer view
        momoSourcePresetSelect = $("#momo-source-preset-select");
        momoTargetPresetSelect = $("#momo-target-preset-select");
        momoSourceEntriesContainer = $("#momo-source-entries-container");
        momoTransferEntriesBtn = $("#momo-transfer-entries-btn");

        $(`#${CLOSE_BUTTON_ID}`).on("click touchend", closePopup);
        overlay.on("click", function (event) {
            if (event.target === this) closePopup();
        });
        $(`#${POPUP_ID}`).on("click", (e) => e.stopPropagation());
        // 根据用户要求，始终保持高级功能按钮为可点击状态
        editActionsContainer.removeClass('momo-disabled').find('button').prop('disabled', false);
        editPresetSelect.on("change", function () {
            // 保留样式切换，但不再禁用按钮
            const isPresetSelected = !!$(this).val();
            editActionsContainer.toggleClass("momo-disabled", !isPresetSelected);
        });
        $(".momo-popup-body").on(
            "click",
            ".momo-back-to-main-btn",
            showMainView
        );
        gotoModifyBtn.on("click", () => showSubView("momo-modify-view"));
        gotoBatchDeleteBtn.on("click", () =>
            showSubView("momo-batch-delete-view")
        );
        gotoTransferBtn.on("click", () => showSubView("momo-transfer-view"));
        momoModifyPresetSelect.on("change", populatePresetSettingSelect);
        momoSettingSelect.on("change", handleSettingSelectionChange);
        momoSubmitModificationBtn.on("click", handleSubmitModification);
        momoSaveManualChangesBtn.on("click", handleManualSave);

        // Batch delete events
        batchDeletePresetsBtn.on("click", handleBatchDeletePresets);
        batchDeleteEntriesBtn.on("click", handleBatchDeleteEntries);

        // Transfer events
        momoSourcePresetSelect.on("change", renderSourceEntries);
        momoTransferEntriesBtn.on("click", handleTransferEntries);

        const isEnabled = localStorage.getItem(STORAGE_KEY_ENABLED) !== "false";
        $(TOGGLE_ID).prop("checked", isEnabled);
        $(document).on("change", TOGGLE_ID, function () {
            localStorage.setItem(
                STORAGE_KEY_ENABLED,
                $(this).is(":checked").toString()
            );
            $(this).is(":checked")
                ? initializeFloatingButton()
                : destroyFloatingButton();
        });

        if (isEnabled) {
            initializeFloatingButton();
        }

        $("#momo-check-update-button").on("click", () =>
            Updater.checkForUpdates(true)
        );
        Updater.checkForUpdates(false);
    }

    // 直接初始化扩展，API的获取推迟到需要时进行
    initializeExtension();
    console.log(`[${extensionName}] 扩展UI已初始化。API将在需要时连接。`);
});
